<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', '' );

/** MySQL database username */
define( 'DB_USER', '' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', '' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '>9<_9$/m`.v5Kl[.!_WytR5&d%OBi Le4*N(6Y:fceV=rhGe%6c5![EhM|71fhA)' );
define( 'SECURE_AUTH_KEY',  'tkqx+[3/7:Slt(hC}lJilnD*]l?72bQp{{7fF}.AX]boDUT7;Tj2ucRP&|:gS_6Y' );
define( 'LOGGED_IN_KEY',    'YS5aTm)Y&jMz0N-T-Ppbz~`eIqQ2b*?F08 s$lWrCAOU!1g+f(in%]GYeY+4MhP%' );
define( 'NONCE_KEY',        'Ih5K/ FOBz-:gFj!A]-h6hJR(%<uVA9*bP/,*kK9SvqfkPQz#.1gg5pGYf/G,a:4' );
define( 'AUTH_SALT',        ']f6I58KeKb|.f|YEQQy;8dmYG) t!9g-`![w%}jcq.P#LwIm*,;rj7#^GVUo;5]O' );
define( 'SECURE_AUTH_SALT', ',xQMk/{@SY;#6}6IFn{wO=}qlO}ZECc,,e,~GTxn-:0[<J?q+&&q,/pL[SH70di.' );
define( 'LOGGED_IN_SALT',   'A>&rkv[3OPR&y54[NGC@SaO/{qFD.U{c9vq?{R^M|~:x5pM{X=)C}I&*eVfUV1qJ' );
define( 'NONCE_SALT',       'J}xnN$4b?l;-Q=T9OM!KffMJTp.Dvb<[;nN^JyuH.E7d1Sn|_9#&ILr^}%a2``vo' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
// define( 'WP_DEBUG', false );

define( 'WP_DEBUG', true );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );